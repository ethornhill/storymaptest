define({
  "commonMapControls": {
    "common": {
      "settings": "Pengaturan",
      "openDefault": "Buka secara default"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Peta Dasar",
      "expandFactorLabel": "Perluas Faktor",
      "expandFactorPopover": "Rasio antara ukuran inset peta dan jangkauan yang ditampilkan pada inset peta. Nilai defaultnya 2, artinya peta ikhtisar setidaknya berukuran dua kali jangkauan persegi panjang."
    }
  }
});