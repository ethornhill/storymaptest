define({
  "commonMapControls": {
    "common": {
      "settings": "設定",
      "openDefault": "デフォルトで開く"
    },
    "overview": {
      "basemapGalleryBtnLabel": "ベースマップ",
      "expandFactorLabel": "拡大係数",
      "expandFactorPopover": "概観図と概観図に表示される範囲矩形のサイズの比率です。デフォルト値は 2 で、概観図は矩形範囲の少なくとも 2 倍のサイズがあります。"
    }
  }
});