require(
	[
		"storymaps/common/Core",
		"storymaps/tpl/core/MainView",
		"storymaps/common/builder/Builder",
		"storymaps/tpl/builder/BuilderView"
	],
	function()
	{
		// Nothing here
	}
);
