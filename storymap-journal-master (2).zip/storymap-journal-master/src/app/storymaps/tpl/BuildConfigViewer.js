require(
	[
		"storymaps/common/Core",
		"storymaps/tpl/core/MainView"
	],
	function()
	{
		// Nothing here
	}
);
